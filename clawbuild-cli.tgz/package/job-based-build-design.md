# ClawBuild YAML-Based Android Build CLI Design

## 1. Core Idea

ClawBuild is an Android build control CLI. It should not hardcode project
commands, module names, log paths, artifact paths, or deployment behavior.

The stable contract is:

```text
YAML describes what to build.
CLI executes and observes it.
Agent reads structured state and decides the next safe action.
```

This keeps the CLI useful for MTK, Unisoc, ODM baselines, local Gradle projects,
and project-specific custom modules.

## 2. Current Scope

Implemented scope:

- local and remote execution
- SSH2 remote control from Linux, macOS, or Windows controller machines
- Linux/macOS build machines
- detached runner
- session history
- dashboard
- webhook event reporting
- YAML-driven jobs and modules
- workspace templates
- machine and credential configuration
- runner mutual exclusion on one physical build machine
- Docker simulation with multiple build machines
- typed deployment dry-runs and execution plans
- `yaml doctor` checks for agent-safe YAML

Explicitly not implemented yet:

- real-device validation
- automatic LLM network calls inside CLI

Deployment and flashing are implemented as explicit artifact modes, not as
agent-inferred behavior. Docker can validate command planning, but real device
state still requires human or environment-specific confirmation.

## 3. YAML Layers

```text
workspace-template
  reusable project layout, for example Phoenix MTK mssi/vnd/modem roots

workspace
  private local binding: project name, real root paths, machine reference

job
  executable build method: cwd, command, logs, artifacts, checks

module
  user-facing build target: Settings, SystemUI, Launcher, modem_img, etc.
```

Modules point to jobs. A module can list multiple jobs, and the CLI selects the
one compatible with the current workspace roots.

## 4. Preset YAML and Custom YAML

Preset YAML is shared and versioned by the project. It should be portable and
should not contain private machines, passwords, or one user's checkout path.

Custom YAML is generated or edited for a real project. It can bind module names,
project names, monitored logs, artifacts, and project-specific paths.

Recommended flow:

```text
clawbuild yaml create
  -> clawbuild yaml validate
  -> clawbuild yaml explain
  -> human review
  -> clawbuild trigger
```

If LLM generation is added, it should only generate a draft YAML. The CLI must
still validate and explain before execution.

## 5. Agent-Friendly Contract

Agent-facing commands should support JSON:

```bash
clawbuild yaml list --json
clawbuild yaml show --id <id> --json
clawbuild yaml explain --id <id> --json
clawbuild yaml validate --json
clawbuild yaml doctor --id <id> --json

clawbuild context --json
clawbuild plan --request "编译 Launcher" --json
clawbuild trigger --module Launcher --json
clawbuild status --session <session-id> --json
clawbuild logs --session <session-id> --json
clawbuild artifacts --session <session-id> --json
clawbuild dashboard --json
```

Human-facing commands should remain readable:

```bash
clawbuild dashboard --watch --interval 20s --logs --tail 10
clawbuild module list
clawbuild yaml explain --id phoenix-modem-img
```

## 6. Module Requirements

Every module YAML must declare monitored logs and artifacts.

Reason:

- dashboard needs logs and artifact status
- agents need stable fields instead of guessing paths
- long builds need attach and session recovery
- failures need log tail and error extraction

Minimum module example:

```yaml
schema: clawbuild.module/v1
kind: module
id: phoenix-launcher
project: phoenix
job: phoenix-mssi-module-build
name: Phoenix Launcher

params:
  module: Launcher

monitor:
  logs:
    - id: launcher-log
      role: primary
      path: "${workspace.roots.vnd}/build_log_out/build_Launcher.log"

artifacts:
  - id: launcher-apk
    type: apk
    path: "${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m/system_ext/priv-app/Launcher/Launcher.apk"
    required: true

deployment:
  modes:
    - id: adb-push-apk
```

## 7. Job Requirements

Jobs define execution mechanics:

- matching metadata
- params
- required workspace roots
- preflight checks
- actions and commands
- monitor logs
- artifacts
- agent hints

Example action:

```yaml
actions:
  build:
    dir: "${workspace.roots.vnd}"
    required_roots: [mssi, vnd]
    cmds:
      - "./build_script/build.sh ${project} ${variant} mm ${module}"
```

`cmds` run serially. This is intentional for long Android builds where logs,
failure attribution, and resource control matter more than task-level
parallelism.

## 8. Remote and Local Modes

Local mode:

```text
controller CLI == build machine
runner executes on local host
```

Remote mode:

```text
controller CLI connects through SSH2
runner executes on remote build machine
```

The controller can run on Linux, macOS, or Windows. Build machines are currently
targeted at Linux and macOS.

## 9. Runner Mutual Exclusion

For current Android baseline builds, one physical build machine should run one
ClawBuild runner at a time. This avoids multiple workspaces exhausting CPU,
memory, disk I/O, or vendor build locks.

Different physical machines do not block each other. Local runner and remote
runner are scoped by where the runner actually runs.

## 10. Dashboard and Events

Dashboard should show:

- live/dead runner state
- build phase
- session id
- workspace
- recent sessions
- resource snapshot
- high-activity process when logs are quiet
- artifact existence
- optional log tail

Webhook events are useful for Hermes or other long-running agent supervision.
Polling remains the fallback for agents without webhook support.

## 11. Security Rules

- Never store SSH passwords in shared YAML.
- Controller-side credentials live in `~/.clawbuild/machines.yaml`.
- Generated YAML must be reviewed before execution.
- Deployment and flashing must come from declared `deploy_modes`, not agent
  guesses. Prefer `clawbuild deploy --dry-run` before executing on real devices.
- Prefer structured JSON output for agent use.

## 12. Deployment Modes

Artifacts may declare `deploy_modes`. The CLI supports:

- `adb-push-file`: generic file push to `device_path`.
- `adb-push-jar`: push a JAR, usually under `/system/framework`.
- `adb-push-apk`: push a privileged/system APK.
- `adb-install`: install a user APK.
- `fastboot-flash-image` / `fastboot-flash`: flash an image to a partition.
- `shell-script`: run a deployment script.

`yaml create` filters requested deploy modes by artifact type. For example, if
the user passes both `adb-push-jar` and `adb-push-apk`, `.jar` artifacts keep
only `adb-push-jar` and `.apk` artifacts keep only `adb-push-apk`.

Framework-style modules with many outputs should use list files instead of
large shell argument expansions:

```bash
clawbuild yaml create \
  --project phoenix \
  --name framework-minus-apex \
  --from-prompt "根据指南编译 framework-minus-apex" \
  --command-file /tmp/framework-command.txt \
  --artifact-root '${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m' \
  --artifact-list /tmp/framework-artifacts.txt \
  --device-path-root /system/framework \
  --deploy-mode adb-push-jar \
  --deploy-mode adb-push-apk
```
