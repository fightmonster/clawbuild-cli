# ClawBuild PRD

## 1. Product Positioning

ClawBuild is an agent-friendly Android build CLI for local and remote build
machines. It is designed for long-running AOSP, MTK, Unisoc, and ODM baseline
builds where the build process may last for hours and the machine may be under
heavy load.

The product goal is not to replace vendor build scripts. The goal is to wrap
them with a stable control plane:

```text
configure -> trigger -> monitor -> inspect -> collect artifacts
```

## 2. Design Principles

### YAML-driven, not project-hardcoded

The CLI must not hardcode Phoenix, CarrierFree, MTK, Unisoc, Settings, SystemUI,
Launcher, modem, or artifact paths. Project-specific behavior belongs in YAML.

### Agent-friendly and human-friendly

Every important operation should have stable JSON output for agents and readable
text output for humans.

### Detached execution

The build runner must continue even if the controller CLI exits, the SSH
terminal disconnects, or the agent restarts.

### File-based monitoring

Long Android logs are written to files. ClawBuild tails declared log files and
stores session state instead of depending on fragile stdout pipes.

### Explicit artifacts

Every module YAML must declare artifacts. The CLI should not scan the whole
Android `out` tree and guess what the user wants.

### Explicit deployment modes

Deployment is YAML-declared and opt-in per artifact. The CLI supports dry-run
planning and execution for typed deployment modes such as adb push, adb install,
fastboot flash, and shell-script based flashing. Agents must not invent deploy
commands; they may only use `deploy_modes` declared by the artifact and should
prefer `clawbuild deploy --dry-run` before execution.

## 3. Main Users

- Human Android platform engineers.
- Hermes or other agents controlling builds.
- Local developers testing build profiles.
- Build coordinators managing multiple build machines.

## 4. Core Functional Requirements

### Workspace Management

Users should configure a build workspace once and update it later if host,
workspace root, or machine metadata changes.

```bash
clawbuild setup ...
clawbuild workspace init ...
clawbuild workspace list --json
clawbuild workspace show --name phoenix --json
```

Workspace YAML is private local state. It can reference a machine by name, but
should not store passwords.

### Machine and Credential Management

Controller-side credentials are stored in `~/.clawbuild/machines.yaml`.

Supported use case:

- default Android build machines: username `android`, configured password
- high-performance machines can be added later as another credential group
- users only need to know IP/host on first setup
- machine name can be discovered from hostname or assigned explicitly

### YAML Registry

The CLI must list, show, explain, validate, create, publish, and update YAML
profiles.

```bash
clawbuild yaml list --json
clawbuild yaml show --id phoenix-modem-img --json
clawbuild yaml explain --id phoenix-modem-img --json
clawbuild yaml validate --json
clawbuild yaml doctor --id phoenix-modem-img --json
clawbuild yaml create --project phoenix --name Launcher --from-prompt "制作 Launcher 模块编译 yaml"
clawbuild registry remote list --channel stable --project phoenix
clawbuild registry publish --channel custom --file ~/.clawbuild/modules/phoenix-launcher.yaml
clawbuild registry check --channel stable --project phoenix
clawbuild registry update --channel stable
```

Remote registry channels:

- `stable`: developer-validated YAML. ClawBuild may check this channel
  automatically at task start and present an update plan.
- `custom`: user-created YAML. Users can upload and explicitly install it, but
  it is not checked or applied by default.

Avoid the term `beta`. In ClawBuild, unvalidated shared YAML is `custom`; once
validated by a maintainer, it is promoted to `stable`.

Every registry YAML has a SemVer `version`. Filenames also include the version
for fast listing and cache lookup:

```text
stable/phoenix/modules/phoenix-framework-minus-apex@1.0.0.yaml
custom/phoenix/modules/phoenix-launcher@0.1.0.yaml
```

Module and job YAML must be updated as a dependency graph centered on jobs.
Modules normally depend on jobs. When a job has a new version, ClawBuild must
check every installed module that references that job. If the module has a newer
remote version, it joins the update plan; if the module version is unchanged,
ClawBuild keeps it but checks compatibility metadata when present. Missing
compatibility metadata should warn, not silently assume safety.

The registry also provides promotion, review, atomic groups, and lifecycle
operations:

- `registry promote`: move a reviewed exact `custom` YAML into `stable`, with
  an explicit stable SemVer when appropriate.
- `registry diff`: compare the local effective YAML with a selected remote
  channel/version before updating.
- `registry bundle publish`: bind related job/module YAML into one atomic update
  unit. All objects download and pass checksum validation before any local
  member is written.
- `registry index latest|prune`: list newest records or safely prune historical
  index entries. Stored objects are deleted only with an explicit extra flag.
- `--yaml-version`: select an exact local/remote YAML version for inspection or
  installation.

With a default registry source, `trigger` performs a read-only stable update
check before build start. It never auto-applies a YAML update at that point;
agents can call `registry check --json` to receive the full plan.

The first cloud backend is S3-compatible object storage. CSTCloud S3 AccessKeys
created for the `Rclone` application require a Rclone-like User-Agent:

```yaml
user_agent: rclone/v1.69.3 clawbuild
```

See `docs/yaml-registry.md` for the full registry layout and policy.

### Module Builds

Modules are the user-facing build targets:

- Settings
- SystemUI
- Launcher
- modem image
- other APKs/images

Each module must declare:

- selected job or jobs
- monitored logs
- artifacts
- optional typed deployment modes per artifact
- agent hints when useful

### Jobs

Jobs describe executable build methods:

- working directory
- shell commands
- required roots
- checks
- monitored logs
- artifact paths
- matching metadata

Jobs may support actions such as `new`, `remake`, `build`, `clean`, or
project-specific operations.

### Session Lifecycle

Each trigger creates a session with:

- `session.yaml`
- `session.json`
- `state.env`
- `runner.js`
- `build.log`
- `artifact-manifest.json`
- optional error summary

The user or agent can later run:

```bash
clawbuild status --session <session-id> --json
clawbuild logs --session <session-id> --json
clawbuild errors --session <session-id> --json
clawbuild artifacts --session <session-id> --json
clawbuild attach --session <session-id> --json
clawbuild deploy --session <session-id> --artifact <artifact-id> --dry-run --json
```

### Dashboard

Dashboard must work for humans and agents:

```bash
clawbuild dashboard
clawbuild dashboard --watch --interval 20s --logs --tail 10
clawbuild dashboard --json
```

It should show:

- live runner status
- build status
- workspace
- session id
- latest sessions
- resource snapshot
- high-activity process when logs are quiet
- artifacts
- optional log tail

### Webhook Events

Hermes-style long-running supervision can use webhook events. Polling remains
the fallback for agents without webhook support.

```bash
clawbuild trigger \
  --module MtkSettings \
  --event-webhook http://agent/callback \
  --event-secret <secret>
```

Events should include controller id, runner id, workspace id, session id, build
status, and progress.

### Deployment

Supported deployment mode families:

- `adb-push-file`: push any declared file to `device_path`.
- `adb-push-jar`: push framework/system JARs to `device_path`.
- `adb-push-apk`: push privileged/system APKs to `device_path`.
- `adb-install`: install a user APK with `adb install -r`.
- `fastboot-flash-image` / `fastboot-flash`: flash an image to a partition.
- `shell-script`: run an artifact script or explicit deployment script.

Deployment remains explicit and reviewable. Recommended flow:

```bash
clawbuild artifacts --session <session-id> --json
clawbuild deploy --session <session-id> --artifact <artifact-id> --dry-run --json
clawbuild deploy --session <session-id> --artifact <artifact-id> --json
```

Real-device availability, bootloader state, adb root/remount behavior, and
fastboot safety are environment-dependent and are not fully covered by Docker.

## 5. Non-Goals for Current Version

- No built-in LLM provider call inside CLI.
- No automatic YAML execution after generation.
- No full real-device orchestration UI.
- No Jenkins replacement UI.

## 6. Agent Flow

Recommended agent flow:

```text
context
  -> yaml/module list
  -> explain or plan
  -> trigger
  -> monitor/dashboard/status
  -> logs/errors/artifacts
```

For custom YAML:

```text
user prompt
  -> yaml create draft
  -> yaml validate
  -> yaml doctor
  -> yaml explain
  -> user review
  -> trigger
```

## 7. Test Strategy

Docker tests verify the CLI control plane:

- remote SSH runner
- two simulated build machines
- local + remote dashboard visibility
- logs
- artifacts
- deployment dry-run planning
- webhook
- timeout/cancel/cleanup
- runner mutual exclusion

Docker does not verify real AOSP builds, physical devices, bootloader state,
adb root/remount reliability, fastboot flashing on hardware, or true production
machine load.
