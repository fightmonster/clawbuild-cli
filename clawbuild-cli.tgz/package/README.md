# ClawBuild CLI

ClawBuild is an agent-friendly Android build CLI for local and remote build
machines. It uses YAML profiles to describe workspaces, jobs, modules,
monitored logs, and artifacts.

## Install from GitHub Release TGZ

ClawBuild is distributed as a GitHub release tarball, not through npm publish.

After a release asset is uploaded, install it with npm:

```bash
npm install -g https://github.com/fightmonster/clawbuild-cli/releases/latest/download/clawbuild-cli.tgz
```

Verify:

```bash
clawbuild --version
clawbuild --help
```

Update to the latest GitHub release:

```bash
clawbuild update --dry-run
clawbuild update --yes
```

`clawbuild update` installs from:

```text
https://github.com/fightmonster/clawbuild-cli/releases/latest/download/clawbuild-cli.tgz
```

## Local Development

```bash
npm install
npm test
node bin/clawbuild.js --help
```

For a developer-owned S3 smoke test (credentials are read only from environment
variables), run `npm run test:s3`. The test helper is intentionally excluded
from the release tarball.

Build the release tarball:

```bash
npm pack
```

## YAML Discovery

```bash
clawbuild yaml list
clawbuild yaml list --kind module --project phoenix --json
clawbuild yaml explain --id phoenix-modem-img --json
clawbuild yaml validate --json
clawbuild yaml doctor --id phoenix-modem-img --json
clawbuild doctor --json
```

`clawbuild doctor` is the preflight audit for the effective local YAML set. It
checks schema and registry metadata, project visibility, module-to-job
compatibility declarations, artifact paths and typed deployment modes, plus
basic local runtime/config-directory health. It is read-only and does not
connect to SSH runners. Use `--all` to audit every discovered profile, or
`--kind` / `--project` to narrow the report. This release ships validated
profiles inside the CLI package as immutable `stable + builtin` YAML.
`examples/` is documentation-only. Editable `custom + local` YAML remains in
`~/.clawbuild/` and takes priority when the user intentionally creates or
overrides a profile.

## YAML distribution (offline bundle)

Remote S3 registry access is temporarily disabled because there is no stable
registry service. The verified `stable` YAML set is bundled in the published
tgz under `profiles/stable/`, so it is available immediately after `npm install`
without credentials or a network connection.

```bash
# Show bundled stable profiles and local custom profiles together.
clawbuild yaml list --all

# Create/edit a local custom profile, then audit it.
clawbuild yaml create --project phoenix --name launcher --from-prompt "..."
clawbuild doctor
```

Only the read-only SSH collection helper remains under `clawbuild registry`:

```bash
clawbuild registry collect --machine <machine-name> --json
```

Remote `source`, `remote`, `check`, `update`, `publish`, `promote`, `diff`,
`bundle publish`, and `index` commands return a clear disabled message and do
not make any S3 request. The future cloud workflow is retained as design notes
in [docs/yaml-registry.md](docs/yaml-registry.md), not as an active feature.

To bring a custom YAML created on an SSH build machine back to the controller
without placing S3 credentials on that machine:

```bash
clawbuild registry collect --machine <machine-name> --json
```

The command writes a validated review copy into the controller registry cache;
publish that local file explicitly after review.

Keep S3 credentials in the configured environment variables; do not put an
AccessKey Secret into a YAML file, shell history, or source repository.
`--insecure-tls` exists only for a self-signed development registry such as the
Docker MinIO test environment; never use it with CSTCloud or another production
endpoint.

See [docs/yaml-registry.md](docs/yaml-registry.md) for versioning, stable/custom
promotion, bundle safety, and S3 backend details.

## First Use on a Local Build Machine

If the agent is already running on the build machine, use local setup. No SSH
host, username, password, machine, or credential is required:

First ask ClawBuild to inspect the root and list candidate layouts:

```bash
clawbuild setup \
  --mode local \
  --root /data/platform/Phoenix \
  --workspace-name phoenix \
  --json
```

Then choose one candidate and apply it explicitly:

```bash
clawbuild setup \
  --mode local \
  --root /data/platform/Phoenix \
  --workspace-name phoenix \
  --project-name phoenix \
  --template phoenix-mtk
```

Remote setup is only needed when the controller machine connects to a separate
build machine over SSH.

Before relying on a remote runner, verify the machine from the controller:

```bash
clawbuild machine test --name <machine-name> --remote-session-root /tmp/clawbuild/sessions --json
```

`machine test` checks SSH connectivity, remote `node` compatibility, `bash`,
the remote session root, and available disk space. `trigger --mode remote`
performs the same read-only runner preflight before starting a real detached
session.

For agents, `setup --json` returns:

- `candidate_layouts`: all workspace templates whose roots partially or fully
  match the project directory. Templates can require one, two, three, or more
  roots depending on the platform.
- `selected_layout`: only set when the user or agent explicitly passed
  `--template <id>`.
- `agent_summary`: workspace roots, matching jobs/modules, and safe next
  commands.

ClawBuild does not auto-select MTK, Unisoc, Qualcomm, or any other platform.
The agent should inspect `candidate_layouts`, choose explicitly, and rerun
`setup` with `--template <id>`.

## YAML Authoring for Many Artifacts

For framework-style modules with many artifacts, avoid passing dozens of shell
arguments. Use an artifact list and command file:

```bash
clawbuild yaml create \
  --project phoenix \
  --name framework-minus-apex \
  --from-prompt "根据指南编译 framework-minus-apex" \
  --command-file /tmp/framework-command.txt \
  --artifact-list /tmp/framework-artifacts.txt \
  --artifact-root '${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m' \
  --device-path-root /system/framework \
  --deploy-mode adb-push-jar \
  --deploy-mode adb-push-apk \
  --json
```

Then check:

```bash
clawbuild yaml validate --id phoenix-framework-minus-apex --json
clawbuild yaml doctor --id phoenix-framework-minus-apex --json
clawbuild yaml explain --id phoenix-framework-minus-apex --json
```

## Deployment

Deployment is explicit per artifact. Supported modes include:

- `adb-push-file`
- `adb-push-jar`
- `adb-push-apk`
- `adb-install`
- `fastboot-flash-image`
- `fastboot-flash`
- `shell-script`

Always preview before mutating a device:

```bash
clawbuild deploy --session <session-id> --artifact <artifact-id> --dry-run --json
```

When applying a deployment, select the artifact and mode explicitly. Use
`--device <serial>` when more than one adb/fastboot target may be attached:

```bash
clawbuild deploy \
  --session <session-id> \
  --artifact <artifact-id> \
  --deploy-mode adb-push-apk \
  --device <serial> \
  --json
```

Real deployment performs preflight checks before mutating a device: artifact
existence, declared deploy mode, required `adb` or `fastboot` tool availability,
and attached target discovery.

## Current Limits

ClawBuild does not include a Jenkins-style web UI or a built-in LLM provider.
Docker tests verify deployment command planning, not physical adb/fastboot
hardware behavior.

## Log Monitoring

ClawBuild monitors build logs with bounded reads. Runner progress snapshots keep
only a small tail window, and error summaries prefer `ugrep` when it is
available on the build machine. If `ugrep` is missing, ClawBuild falls back to a
bounded tail scan instead of reading the whole log file.

Detached sessions write both `state.env` and `state.json`. The JSON mirror keeps
status consumers from having to parse shell env files, while log commands read
only bounded tails for progress, attach streaming, and error summaries.

Optional limits:

```bash
CLAWBUILD_LOG_TAIL_BYTES=2097152
CLAWBUILD_LOG_DELTA_BYTES=1048576
```
