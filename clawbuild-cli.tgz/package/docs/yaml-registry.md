# ClawBuild YAML distribution

## Current release: offline bundled stable profiles

Remote registry/S3 access is **temporarily disabled**. It is not contacted by
task startup and the CLI does not offer upload, publish, promote, remote-list,
check, update, diff, or index maintenance commands.

The verified profile set is distributed with every npm/tgz package:

```text
clawbuild-cli/
  profiles/stable/
    jobs/
    modules/
    workspace-templates/
```

At runtime these files are reported as `channel: stable`, `origin: builtin` and
are read-only package assets. User-authored files live in
`~/.clawbuild/{jobs,modules,workspace-templates}/`, are reported as
`channel: custom`, `origin: local`, and are deliberately editable. Use
`clawbuild yaml list --all` and `clawbuild doctor` to inspect the effective
set. `clawbuild registry collect` remains available solely to collect YAML from
an SSH build machine into the controller's local custom area.

The rest of this document records the intended remote-registry design for a
future stable service. It is not active behavior in this release.

## Channels

The future registry has only two channels:

- `stable`: validated YAML maintained by project owners/developers. This is the only channel that can be checked automatically before normal tasks.
- `custom`: user-created YAML uploaded for sharing. It is not automatically selected for builds and must be installed explicitly.

The current release instead bundles its validated `stable` set locally. There
is no active `official` channel.

Use two separate fields:

```text
channel = stable | custom
origin  = builtin | registry | local
```

Examples:

```text
stable + builtin     validated YAML distributed in this CLI tgz (current)
custom + local       YAML created or edited on this machine (current)
custom + registry    YAML downloaded from a future remote custom channel
stable + registry    developer-promoted YAML from a future service
```

Do not use `beta` as a channel name. User-created YAML belongs to `custom`; validated YAML is promoted to `stable`.

## Local preflight audit

Run this before publishing YAML or starting a build after changing profiles:

```bash
clawbuild doctor
clawbuild doctor --project phoenix --json
clawbuild doctor --all                 # Audit every discovered local profile.
clawbuild yaml doctor --kind module --id phoenix-settings
```

`clawbuild doctor` is read-only. It audits the effective local YAML set and
basic local runtime health; it does not contact SSH runners or start a build.
It reports errors for profiles that cannot run and warnings for registry
quality issues, including missing registry metadata, missing `project`, missing
module-to-job compatibility rules, host-specific build paths, and incompatible
artifact deployment modes. `clawbuild yaml doctor` remains the focused form
for one YAML.

## Version rules

Every registry YAML should contain a SemVer version:

```yaml
version: 1.0.0
```

Suggested meaning:

- `PATCH`: metadata/log/artifact-path fixes that do not change build behavior.
- `MINOR`: backward-compatible additions, such as extra artifacts or deploy modes.
- `MAJOR`: build command, workspace root, job behavior, or deployment behavior changes.

User-created YAML normally starts at `0.1.0` in `custom`. When a developer validates it and promotes it to `stable`, it should become `1.0.0` unless there is a reason to keep a lower major version.

## Bundles and dependency safety

Module YAML and job YAML are not independent. A module normally depends on one
or more jobs. The job is the shared execution method; modules add module names,
logs, artifacts, and deployment metadata.

A module may reference one job:

```yaml
job: phoenix-framework-minus-apex-build
```

or several candidate jobs:

```yaml
jobs:
  - phoenix-mssi-module-build
  - phoenix-framework-minus-apex-build
```

Registry updates must be planned as a job-centered dependency graph:

1. If a job has a new version, find every installed module that references it.
2. For each dependent module, check whether remote `stable`/`custom` has a newer
   module version.
3. If a dependent module has a newer version, add it to the update plan.
4. If a dependent module has the same version, keep it, but verify compatibility
   metadata when present.
5. If no newer module exists and no compatibility metadata exists, warn the user.
6. If compatibility metadata says the module is incompatible with the new job,
   block `--apply` unless `--force` is passed.
7. If a bundle exists, install all bundle members together.
8. ClawBuild downloads and verifies every bundle member before writing any local
   YAML. A missing object or checksum failure leaves the existing local bundle
   unchanged.

Version equality matters: a job update does not mean every module is downloaded
again. The CLI checks every dependent module, but only installs modules whose
remote version is newer.

Recommended compatibility metadata:

```yaml
requires:
  jobs:
    - id: phoenix-mssi-module-build
      min_version: 1.0.0
      max_version_exclusive: 2.0.0
```

This deliberately avoids full npm-style dependency solving. ClawBuild supports a
small, conservative compatibility check: `min_version`,
`max_version_exclusive`, or exact `version`.

The first implementation can operate on individual YAML items, but the index format keeps room for bundle metadata:

```json
{
  "bundle_id": "phoenix-framework-minus-apex",
  "version": "1.0.0",
  "channel": "stable",
  "items": [
    { "kind": "module", "id": "phoenix-framework-minus-apex", "version": "1.0.0" },
    { "kind": "job", "id": "phoenix-framework-minus-apex-build", "version": "1.0.0" }
  ]
}
```

## Remote layout

Use versioned filenames for fast listing and cache safety:

```text
clawbuild-registry/
  index.json
  stable/
    phoenix/
      modules/
        phoenix-framework-minus-apex@1.0.0.yaml
      jobs/
        phoenix-framework-minus-apex-build@1.0.0.yaml
      bundles/
        phoenix-framework-minus-apex@1.0.0.json
  custom/
    phoenix/
      modules/
        phoenix-launcher@0.1.0.yaml
      jobs/
        phoenix-launcher-build@0.1.0.yaml
```

The filename version is an index optimization. The YAML body remains authoritative. If the filename version and YAML `version` disagree, future validation should reject the item.

## Local install manifest

Downloaded registry YAML is installed into the active local YAML directories so
existing commands can use it immediately:

```text
~/.clawbuild/modules/<id>@<version>.yaml
~/.clawbuild/jobs/<id>@<version>.yaml
~/.clawbuild/workspace-templates/<id>@<version>.yaml
```

ClawBuild also records install metadata:

```text
~/.clawbuild/registry-installed.json
```

For the Docker MinIO test registry only, `registry source add --insecure-tls`
permits its generated self-signed certificate. Production S3 sources must omit
this flag so TLS certificates remain strictly verified.

This manifest stores origin, channel, registry source, sha256, install time, and
dependencies. Before `registry update --apply` overwrites an installed file, the
current local sha256 is compared with the manifest. If the user edited the file
locally, ClawBuild refuses to overwrite it unless `--force` is passed.

Local selection rules:

```text
custom > stable > official
```

Within the same channel, the highest SemVer version wins. This means a local
custom YAML intentionally overrides a downloaded stable YAML with the same
module/job id.

## Index format

`index.json` is the fast path for listing and update checks:

```json
{
  "schema": "clawbuild.registry-index/v1",
  "updated_at": "2026-07-15T00:00:00.000Z",
  "items": [
    {
      "kind": "module",
      "id": "phoenix-framework-minus-apex",
      "project": "phoenix",
      "version": "1.0.0",
      "channel": "stable",
      "path": "stable/phoenix/modules/phoenix-framework-minus-apex@1.0.0.yaml",
      "sha256": "...",
      "summary": "Build framework-minus-apex",
      "dependencies": {
        "job": "phoenix-framework-minus-apex-build",
        "jobs": ["phoenix-framework-minus-apex-build"]
      },
      "publisher": {
        "name": "luojun",
        "email": "user@example.com",
        "host": "builder-host",
        "tool": "clawbuild",
        "published_at": "2026-07-15T00:00:00.000Z"
      }
    }
  ],
  "bundles": []
}
```

Identity for install/update checks:

```text
kind + id + version + channel
```

Checksum is still required because users may modify local files with the same id/version.

## Update policy

Default behavior:

- Automatically check `stable` when configured.
- Automatically download/cache new metadata.
- Do not automatically apply updates unless the user opts in.
- Never check or apply remote `custom` by default.
- Protect locally modified YAML from overwrite.

Recommended policy shape:

```yaml
update_policy:
  check_on_task_start: true
  auto_download: true
  auto_apply_patch: false
  auto_apply_minor: false
  auto_apply_major: false
  protect_local_changes: true
```

For agent usage, `registry update` should emit an update plan first. The agent may apply safe patch updates only when policy allows it. Job command changes, workspace root changes, and deploy/fastboot behavior changes should require explicit confirmation.

Before `trigger`, ClawBuild performs this same **read-only stable check** when
`check_on_task_start` is enabled and a default source exists. It never applies
an update during a build start; when updates exist it writes a concise notice to
stderr so human output and `--json` trigger output remain usable. Use
`clawbuild registry check --json` when an agent needs the full plan.

## S3 backend

CSTCloud S3 should be configured as a standard S3-compatible backend:

```yaml
sources:
  cstcloud:
    type: s3
    endpoint: https://s3.cstcloud.cn
    bucket: 81bf0b2a345748b1b0dbd60a468502f2
    region: us-east-1
    prefix: clawbuild-registry
    force_path_style: true
    signature_version: v4
    access_key_env: CLAWBUILD_S3_ACCESS_KEY_ID
    secret_key_env: CLAWBUILD_S3_SECRET_ACCESS_KEY
    user_agent: rclone/v1.69.3 clawbuild
```

CSTCloud checks the selected client application type. For an AccessKey created as `Rclone`, requests must include a Rclone-like `User-Agent`; otherwise the service may return `401` even with a valid signature.

## Commands

Configure a source:

```bash
clawbuild registry source add \
  --name cstcloud \
  --type s3 \
  --endpoint https://s3.cstcloud.cn \
  --bucket 81bf0b2a345748b1b0dbd60a468502f2 \
  --prefix clawbuild-registry \
  --access-key-env CLAWBUILD_S3_ACCESS_KEY_ID \
  --secret-key-env CLAWBUILD_S3_SECRET_ACCESS_KEY \
  --user-agent "rclone/v1.69.3 clawbuild" \
  --default
```

List remote YAML:

```bash
clawbuild registry remote list --channel stable --project phoenix
clawbuild registry remote list --channel custom --project phoenix
```

Publish user-created YAML to `custom`:

```bash
clawbuild registry publish --channel custom --file ~/.clawbuild/modules/phoenix-launcher.yaml
```

## Collect YAML from a remote build machine

The controller can collect custom YAML from an SSH build machine without
installing S3 credentials on that machine. `collect` reads only the remote
`~/.clawbuild/modules`, `jobs`, and `workspace-templates` directories, filters
out YAML already marked as `stable + registry` by default, then writes a review
copy into the controller cache:

```bash
clawbuild registry collect --machine phoenix-builder --json
```

The response includes `collection_path`, each file's sha256 and structural
validation result. Review the collected copy, then publish explicitly from the
controller:

```bash
clawbuild registry collect --machine phoenix-builder
clawbuild registry publish --channel custom \
  --file ~/.clawbuild/registry-cache/collected/phoenix-builder/<timestamp>/modules/phoenix-launcher@0.1.0.yaml
```

Use `--remote-dir <path>` if the remote CLI config is elsewhere, `--output`
for a deliberate local review directory, and `--all` only when stable registry
copies should be collected too. The collector has an 8 MiB source limit by
default; tune it with `--max-bytes` for a known large YAML set.

After review, `--install` copies valid collected YAML into the controller's
active local custom directory. It refuses to overwrite a same-name local YAML
unless `--force` is explicit:

```bash
clawbuild registry collect --machine phoenix-builder --install
```

To migrate older local YAML files that predate registry metadata, use:

```bash
clawbuild yaml metadata update --dry-run
clawbuild yaml metadata update --version 0.1.0 --channel custom --origin local
```

This adds only missing `kind`, `schema`, `version`, and `source` fields; it
does not change build commands, paths, logs, artifacts, or existing metadata.

Publish validated YAML to `stable`:

```bash
clawbuild registry publish --channel stable --file ~/.clawbuild/modules/phoenix-launcher.yaml --version 1.0.0
```

Plan and apply updates:

```bash
clawbuild registry update --channel stable
clawbuild registry update --channel stable --apply
clawbuild registry update --channel stable --apply --force
```

Inspect an update without applying it, compare one local YAML against the
remote version, or select an exact version:

```bash
clawbuild registry check --channel stable --project phoenix --json
clawbuild registry diff --kind module --id phoenix-framework-minus-apex
clawbuild registry update --channel stable --id phoenix-framework-minus-apex --yaml-version 1.2.0 --apply
clawbuild yaml show --kind module --id phoenix-framework-minus-apex --yaml-version 1.2.0
```

## Promotion and bundles

Creators publish into `custom`. A maintainer reviews the generated YAML, then
promotes the exact object to `stable`. Promotion copies the checked object,
updates its channel metadata and version, and records its original channel and
version. Use `--to-version` whenever validation represents a release change:

```bash
clawbuild registry promote \
  --id phoenix-framework-minus-apex \
  --kind module \
  --from custom --from-version 0.1.0 \
  --to stable --to-version 1.0.0
```

Jobs and their dependent modules can be declared as one atomic bundle. Publish
the YAML files first, then create the bundle index record:

```bash
clawbuild registry bundle publish \
  --id phoenix-framework-build --version 1.0.0 --channel stable --project phoenix \
  --member job:phoenix-framework-minus-apex-build@1.0.0 \
  --member module:phoenix-framework-minus-apex@1.0.0
```

An update touching any bundle member brings every member into the same plan.

## Index maintenance

Registry indexes retain historical versions by default. Use `latest` for a
compact release view. `prune` removes superseded versions from the index only
unless `--delete-objects` is explicitly supplied; always inspect the dry-run
first:

```bash
clawbuild registry index latest --channel stable --project phoenix
clawbuild registry index prune
clawbuild registry index prune --apply
clawbuild registry index prune --apply --delete-objects
```
