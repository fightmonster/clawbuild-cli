# ClawBuild YAML Profile Schema

ClawBuild is driven by YAML profiles. The CLI should stay project-agnostic:
Android project layout, build commands, monitored logs, artifacts, and future
deployment rules belong in YAML, not in CLI code.

Current profile classes:

- `workspace-template`: reusable project layout template.
- `workspace`: local private binding for one concrete checkout or build host.
- `job`: executable build method.
- `module`: user-facing module entry that points to one or more jobs.

## Directories

By default ClawBuild reads:

```text
~/.clawbuild/jobs
~/.clawbuild/modules
~/.clawbuild/workspace-templates
~/.clawbuild/workspaces
```

They can be overridden:

```bash
CLAWBUILD_JOBS_DIR=/path/to/jobs \
CLAWBUILD_MODULES_DIR=/path/to/modules \
CLAWBUILD_WORKSPACE_TEMPLATES_DIR=/path/to/workspace-templates \
clawbuild yaml list --json
```

## Preset YAML vs Custom YAML

Preset YAML is shipped by the project or team. It should not contain private
paths, hosts, users, passwords, or device-specific state.

Custom YAML is created or edited by a user for a real project. It may bind to a
specific project name, module, artifact path, and log path, but secrets still
belong in controller-side machine configuration.

Recommended precedence:

```text
preset YAML < custom YAML < workspace binding < CLI flags
```

## Workspace Template

Workspace templates describe project layout. They do not describe one user's
real host.

```yaml
kind: workspace-template
id: phoenix-mtk
name: Phoenix MTK workspace
project: phoenix
vendor: mtk
execution_mode: remote
product: asw2601m
variant: userdebug

roots:
  root: "${root}"
  mssi: "${root}/mssi"
  vnd: "${root}/vnd"
  modem: "${root}/modem"

root_validation:
  required_roots: [root, mssi, vnd, modem]

runtime:
  remote_session_root: /tmp/clawbuild/sessions
```

## Job Profile

A job is an executable build method. Jobs define commands, required roots,
checks, monitored logs, artifacts, and agent routing hints.

```yaml
id: phoenix-mssi-module-build
name: Phoenix MSSI module build
summary: Build one MSSI-side APK module through the Phoenix vendor script.

match:
  vendor: mtk
  project: phoenix
  target: apk
  workspace_layout: mssi-vnd

params:
  project:
    default: asw2601m
  variant:
    default: userdebug
  module:
    required: true

workspace:
  required_roots: [mssi, vnd]
  checks:
    - id: build-sh
      kind: file
      path: "${workspace.roots.vnd}/build_script/build.sh"
      executable: true

execution:
  mode: remote_detached
  shell: bash
  cwd: "${workspace.roots.vnd}"
  process_group: true
  log_strategy: redirect

actions:
  build:
    dir: "${workspace.roots.vnd}"
    required_roots: [mssi, vnd]
    cmds:
      - "./build_script/build.sh ${project} ${variant} mm ${module}"

monitor:
  logs:
    - id: wrapper
      role: wrapper
      path: "${runtime.session_root}/${session_id}/build.log"
    - id: module-log
      role: primary
      path: "${workspace.roots.vnd}/build_log_out/build_${module}.log"
      optional: true

artifacts:
  - id: module-apk
    type: apk
    module: "${module}"
    path: "${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m/system_ext/priv-app/${module}/${module}.apk"
    required: true
```

`workspace.required_roots` is mandatory for every job. It is the portable
workspace contract: names must be unique identifiers such as `root`, `mssi`,
`ussi`, `vnd`, or `modem`. An action may declare its own `required_roots`; for
that action, they are added to the job-level roots. Run
`clawbuild workspace check --job <id>` to verify required roots and declared
checks locally or over SSH before starting a build.

## Module Profile

A module is the user-facing unit. Settings, SystemUI, Launcher, modem image,
and other single-build targets should all be represented as modules.

Every module YAML must declare:

- `id`
- `job` or `jobs`
- `params.module`
- at least one monitored log
- at least one artifact

Example:

```yaml
schema: clawbuild.module/v1
kind: module
id: phoenix-launcher
project: phoenix
job: phoenix-mssi-module-build
name: Phoenix Launcher
summary: Build Phoenix Launcher APK.

params:
  module: Launcher
  artifact_id: launcher-apk
  artifact_name: Launcher.apk

monitor:
  logs:
    - id: launcher-log
      name: Launcher build log
      role: primary
      path: "${workspace.roots.vnd}/build_log_out/build_Launcher.log"
      start_from: eof_for_live_attach

artifacts:
  - id: launcher-apk
    name: Launcher.apk
    type: apk
    module: Launcher
    path: "${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m/system_ext/priv-app/Launcher/Launcher.apk"
    device_path: /system_ext/priv-app/Launcher/Launcher.apk
    deploy_modes: [adb-push-apk]
    required: true

deployment:
  modes:
    - id: adb-push-apk
      type: adb_push
```

## Deployment Status

Deployment is explicit per artifact. An artifact may declare `deploy_modes`.
The CLI can render a deployment plan with `clawbuild deploy --dry-run` and can
execute the declared plan when the user intentionally runs `clawbuild deploy`.

Supported modes:

- `adb-push-file`: generic file push to `device_path`.
- `adb-push-jar`: JAR push to `device_path`.
- `adb-push-apk`: privileged/system APK push to `device_path`.
- `adb-install`: `adb install -r` for installable APKs.
- `fastboot-flash-image` / `fastboot-flash`: flash an image to a partition.
- `shell-script`: run a script artifact or declared deploy script.

Agents must not infer deployment behavior. They should only use declared
`deploy_modes`, run `clawbuild deploy --dry-run` first, and require explicit
user approval before real device mutation.

## YAML Registry Commands

Use these commands for human and agent discovery:

```bash
clawbuild yaml list --json
clawbuild yaml list --kind module --project phoenix --json
clawbuild yaml show --id phoenix-launcher --json
clawbuild yaml explain --id phoenix-launcher --json
clawbuild yaml validate --json
clawbuild yaml doctor --id phoenix-launcher --json
```

`yaml explain` renders paths against the selected workspace when possible. A
YAML file can be structurally valid but not runnable in the current workspace
if required roots are missing.

## Creating Custom YAML

The CLI can create a review-required custom YAML draft:

```bash
clawbuild yaml create \
  --project phoenix \
  --name Launcher \
  --from-prompt "制作 Launcher 模块编译 yaml" \
  --artifact-path '${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m/system_ext/priv-app/Launcher/Launcher.apk'
```

For modules with many artifacts, use files instead of large shell-expanded
argument lists:

```bash
clawbuild yaml create \
  --project phoenix \
  --name framework-minus-apex \
  --from-prompt "根据指南编译 framework-minus-apex" \
  --command-file /tmp/framework-command.txt \
  --artifact-list /tmp/framework-artifacts.txt \
  --artifact-root '${workspace.roots.mssi}/out_sys/target/product/mssi_asw2601m' \
  --device-path-root /system/framework \
  --deploy-mode adb-push-jar \
  --deploy-mode adb-push-apk
```

`--artifact-list` is one artifact path per line. Relative paths are joined with
`--artifact-root`. `--device-path-root` maps artifact basenames to device paths.
Requested deploy modes are filtered by artifact type.

The generated file is a draft. Required flow:

```text
create draft -> yaml validate -> yaml doctor -> yaml explain -> human review -> trigger
```

Future LLM integration should plug into the draft generation step only. It
must not generate and execute YAML silently.

## Validation

Run:

```bash
clawbuild yaml validate --json
clawbuild profile validate --json
```

`yaml validate` checks jobs, modules, and workspace templates. Module validation
requires monitored logs and artifacts because dashboard, logs, artifacts, and
agent status all depend on those declarations.

`yaml doctor` performs agent-safety checks on top of validation:

- referenced jobs exist
- artifact ids are unique
- artifact paths render cleanly against the selected workspace
- local absolute artifact paths exist when they can be checked
- `device_path` is present for adb push modes
- `deploy_modes` are compatible with artifact type
